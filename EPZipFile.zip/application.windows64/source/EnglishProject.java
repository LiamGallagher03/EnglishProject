import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.Rectangle; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class EnglishProject extends PApplet {

int backgroundColor = 0xffBABABA;
int slide = 0;
TCircle[] circles = new TCircle[4];
TBox[] textBoxes = new TBox[2];
String[] longStrings = new String[4];
boolean checkClick;

public void setup() {
  
  setStrings();
}

public void draw() {
  background(backgroundColor);
  switch (slide) {
  case 0: 
    //x, y, radius, text, font Size, c of Text, c of Circle, c of Border, 
    circles[0] = new TCircle(480, 280, 400, "This Medium", 50, 0xffFFFFFF, 0xff000000, 0xffFF0000, 10);
    circles[1] = new TCircle(1440, 280, 400, "Happiness", 50, 0xffFFFFFF, 0xff000000, 0xffFFFF00, 10);
    circles[2] = new TCircle(480, 800, 400, "Work", 50, 0xffFFFFFF, 0xff000000, 0xff00FF00, 10);
    circles[3] = new TCircle(1440, 800, 400, "Conclusion", 50, 0xffFFFFFF, 0xff000000, 0xff0000FF, 10);
    for (TCircle c : circles) c.draw();
    break;
  case 1:
    //x, y, width, height, outsideLength, text, fontSize, textColor, boxColor, strokeWidth, strokeColor 
    textBoxes[0] = new TBox(200, 100, 1520, 200, "Computer Program", 50, 0xffFFFFFF, 0xff000000, 20, 0xffFF0000);
    textBoxes[1] = new TBox(200, 400, 1520, 800, longStrings[0], 40, 0xffFFFFFF, 0xff000000, 20, 0xffFF0000);
    for (TBox box : textBoxes) box.draw();
    checkClick = false;
    break;
  case 2:
    textBoxes[0] = new TBox(200, 100, 1520, 200, "Happiness in Life", 50, 0xffFFFFFF, 0xff000000, 20, 0xffFFFF00);
    textBoxes[1] = new TBox(200, 400, 1520, 800, longStrings[1], 40, 0xffFFFFFF, 0xff000000, 20, 0xffFFFF00);
    for (TBox box : textBoxes) box.draw();
    checkClick = false;
    break;
  case 3:
    textBoxes[0] = new TBox(200, 100, 1520, 200, "Having a Career", 50, 0xffFFFFFF, 0xff000000, 20, 0xff00FF00);
    textBoxes[1] = new TBox(200, 400, 1520, 800, longStrings[2], 40, 0xffFFFFFF, 0xff000000, 20, 0xff00FF00);
    for (TBox box : textBoxes) box.draw();
    checkClick = false;
    break;
  case 4:
    textBoxes[0] = new TBox(200, 100, 1520, 200, "How It All Ties Together", 50, 0xffFFFFFF, 0xff000000, 20, 0xff0000FF);
    textBoxes[1] = new TBox(200, 400, 1520, 800, longStrings[3], 40, 0xffFFFFFF, 0xff000000, 20, 0xff0000FF);
    for (TBox box : textBoxes) box.draw();
    checkClick = false;
    break;
  }
}

public void mouseReleased() {
  if (slide == 0) {
    for (int i = 0; i < 4; i++) {
      if (circles[i].hoveringOver()) {
        checkClick = true;
        backgroundColor = 0xff000000;
        slide = i + 1;
        System.out.print(slide);
        
      }
    }
  }
  if (slide == 1 && checkClick == false) {
    backgroundColor = 0xffBABABA;
    checkClick = true;
    slide = 0;
  }
  if (slide == 2 && checkClick == false) {
    backgroundColor = 0xffBABABA;
    checkClick = true;
    slide = 0;
  }
  if (slide == 3 && checkClick == false) {
    backgroundColor = 0xffBABABA;
    checkClick = true;
    slide = 0;
  }
  if (slide == 4 && checkClick == false) {
    backgroundColor = 0xffBABABA;
    checkClick = true;
    slide = 0;
  }
}

public void setStrings() {
  longStrings[0] = "I have always loved computers since I was seven years old. In addition to this, I always excelled in several mathematical subjects and topics. With these two interests, it only makes sense that I would make the medium regarding my philosophy computer-related. I choose to code the entirety of this instead of doing a simple Google Slide show. The code for this is available on GitHub, using the link I submitted.";
  longStrings[1] = "Generally speaking, everyone in life wants to be happy. No one wants to go out of their way to feel the negative emotions (sadness, anger, etc.), so living a happy life is a common goal amongst everyone. Being happy is fairly simple for most people, but maintaining that happiness throughout life is an entirely different problem.";
  longStrings[2] = "Later in life, most of us will have life-long occupations; some of us will even pursue higher education. It is important that you feel comfortable with the career that you will have for the rest of your life. Some people are very regretful in their occupation and believe it is too late to change. Do not be one of these people.";
  longStrings[3] = "In essence, having a career/occupation that you love is very important for your long-term happiness. You do not want to have any regrets when choosing a career. Yes, some may have to make compromises on their dream occupation due to certain circumstances, but there are multiple other pathways that are readily available. I want to enter the computer science industry, so in order to 'practice' my skills and convey my philosophy, I choose to code the entirety of this project. Hopefully, you can also find something that you love doing for your future-career.";
}
public class TBox { 
  int x, y, w, h, fontSize, strokeWeight;
  String text;
  int textColor, boxColor, strokeColor;
  public TBox(int x, int y, int w, int h, String t, int fS, int tC, int bC, int sW, int sC) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.text = t;
    this.textColor = tC;
    this.fontSize = fS;
    this.boxColor = bC;
    this.strokeWeight = sW;
    this.strokeColor = sC;
  }

  public void draw() {
    stroke(strokeColor);
    strokeWeight(strokeWeight);
    fill(boxColor);
    rect(x, y, w, h); 
    textSize(fontSize);
    fill(textColor);
    textAlign(CENTER);
    text(text, x, y + h/5, w - 50, h - 50);
  }
}


public class TCircle {
  int x, y, r, fontSize, strokeWeight;
  String text;
  int textColor, insideColor, strokeColor;
  public Rectangle clickArea;

  public TCircle(int x, int y, int r, String t, int fS, int tC, int iC, int sC, int sW) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.text = t;
    this.fontSize = fS;
    this.textColor = tC;
    this.insideColor = iC;
    this.strokeColor = sC;
    this.strokeWeight = sW;
    this.clickArea = new Rectangle(x - r, y - r , 2 * r, 2 * r);
  }

  public void draw() {
    stroke(strokeColor);
    strokeWeight(strokeWeight);
    fill(insideColor);
    circle(x, y, r);
    textSize(fontSize);
    fill(textColor);
    textAlign(CENTER);
    text(text, x, y);
  }


  public boolean hoveringOver() {
    return this.clickArea.contains(mouseX, mouseY);
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "EnglishProject" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
